## Test environments

* local OS X install, R 3.1.2
* ubuntu 12.04 (on travis-ci), R 3.1.2
* win-builder (devel and release)

## R CMD check results

There were no ERRORs or WARNINGs.

There was 1 NOTEs:

* checking CRAN incoming feasibility ... NOTE

  .This is a new submission. html and httr are not spelling mistakes.

## Downstream dependencies

This is a new package so there are no downstream dependencies.
